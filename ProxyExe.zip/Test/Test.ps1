[System.Environment]::GetCommandLineArgs() | %{ echo "arg: $_" }
Exit 2